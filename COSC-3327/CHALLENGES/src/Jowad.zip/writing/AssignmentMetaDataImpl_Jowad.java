package writing;

public class AssignmentMetaDataImpl_Jowad implements AssignmentMetaData {

    @Override
    public String getFirstNameOfSubmitter() {
        return "Rifat";
    }

    @Override
    public String getLastNameOfSubmitter() {
        return "Jowad";
    }

    @Override
    public double getHoursSpentWorkingOnThisAssignment() {
        return 7.5;
    }

    @Override
    public int getScoreAgainstTestCasesSubset() {
        return 0;
    }
}
